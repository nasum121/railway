package Domain;

public class SeatType {

    public long id;
    public String type;
}
