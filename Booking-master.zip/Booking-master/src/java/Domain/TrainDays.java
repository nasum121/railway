package Domain;

public class TrainDays {

    public long trainId;
    public boolean sun;
    public boolean mon;
    public boolean tue;
    public boolean wed;
    public boolean thr;
    public boolean fri;
    public boolean sat;
}
