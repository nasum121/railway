/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Domain;

/**
 *
 * @author vishnu-pt517
 */
public class Box {

    public int boxNo;
    public int total;
    public int Lower;
    public int Middle;
    public int Upper;
    public int Side;
    public int[] Lowers = new int[2];
    public int[] Middles = new int[2];
    public int[] Uppers = new int[2];
}
