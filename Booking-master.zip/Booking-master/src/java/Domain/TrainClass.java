package Domain;

public class TrainClass {

    public long trainId;
    public long classID;
    public int total_compartment;
    public int rac;
    public int waiting;
    public int available;
}
