package Domain;

public class Train {

    public long trainId;
    public String name;
    public long fromStationId;
    public long toStationId;
    public int travelTime;
}
