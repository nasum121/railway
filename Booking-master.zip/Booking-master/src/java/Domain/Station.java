package Domain;

public class Station {

    public long id;
    public String name;
}
