package Domain;

public class UnderPassenger {

    public long pnr;
    public String name;
    public int age;
    public int gender;
    public long status_id;
    public int no;
}
