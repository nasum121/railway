package Domain;

public class TrainClassStatus {

    public long trianClassStatusId;
    public long statusId;
    public long classId;
    public int total;
    public int available;
    public int maxWaiting;
    public int sno;
    public int waiting;
    public int initialWaiting;
    public int rac;
    public int maxRac;
    public boolean chart;
    public int last_status_id;
    public int last_seat_no;
    public int a_available;

    @Override
    public String toString() {
        return "TCSID:" + trianClassStatusId + "StatusID:" + statusId + "maxRac:" + maxRac + "RAC:" + rac;
    }
}
