package Domain;

public class Class {

    public long id;
    public String name;
    public String code;
}
