/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Domain;

/**
 *
 * @author vishnu-pt517
 */
public class TrainClassRacStatus {

    public long trainClassRacStatusId;
    public long trainClassStatusId;
    public long racNo;
    public long seatNo;
    public boolean availability;
}
