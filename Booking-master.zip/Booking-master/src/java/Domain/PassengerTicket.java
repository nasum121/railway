package Domain;

public class PassengerTicket {

    public long pnr;
    public long fromStationId;
    public long toStationId;
    public double basicfare;
    public double reservationFare;
    public double serviceCharge;
    public int totalFare;
    public int Adult;
    public int Children;
    public long timestamp;
    public long trainClassStatusId;
}
