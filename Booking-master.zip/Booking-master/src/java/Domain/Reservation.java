package Domain;

import java.util.Date;

public class Reservation {

    public long pnr;
    public long journeyID;
    public int ReservationStatus;
    public Date timestamp;
    public int userId;
    public long classId;
    public long trainClassStausID;
}
