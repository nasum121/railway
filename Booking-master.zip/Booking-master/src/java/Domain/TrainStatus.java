package Domain;

public class TrainStatus {

    public long statusId;
    public long journeyId;
}
