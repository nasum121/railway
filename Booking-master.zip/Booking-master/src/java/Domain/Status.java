/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Domain;

/**
 *
 * @author vishnu-pt517
 */
public class Status {

    public long id;
    public String name;
}
