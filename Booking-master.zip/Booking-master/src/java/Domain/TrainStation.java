package Domain;

import java.sql.Time;

public class TrainStation {

    public long trainId;
    public long stationId;
    public Time arrival;
    public Time dept;
    public int order;
}
