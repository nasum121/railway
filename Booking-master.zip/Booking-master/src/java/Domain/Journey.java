package Domain;

import java.sql.Date;

public class Journey {

    public long Journeyid;
    public long trainId;
    public Date date;
}
