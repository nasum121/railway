#RAILWAY TICKET RESERVATION SYSTEM
####This project gives the deep understanding of the following techs
~~~
*JAVA(j2ee)
*APP SERVER
*MYSQL
*HTML
*CSS
*JS
*JQUERY...
~~~
